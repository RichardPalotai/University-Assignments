﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace BlackHole.Avalonia.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}

