﻿using Avalonia.Controls;

namespace BlackHole.Avalonia.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
