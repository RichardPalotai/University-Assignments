﻿using Avalonia.Controls;

namespace BlackHole.Avalonia.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
