﻿using System;

namespace BlackHole.Persistence
{
    public class BlackHoleDataException : Exception
    {
        public BlackHoleDataException() { }
    }
}
